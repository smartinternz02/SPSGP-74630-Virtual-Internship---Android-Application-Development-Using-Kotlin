package ghanam.com.abdo.dataclasses

data class ChatMessage(val msg:String?, val src:Int)
//1 for user
//0 for robot
